<?php if (class_exists('WooCommerce') && (is_woocommerce() || is_cart() || is_checkout())) return; ?>
<aside id="sidebar" class="col-md-3 right_sidebar">
    <?php if (is_active_sidebar('value_proposition-sidebar-widget')) {
        dynamic_sidebar('value_proposition-sidebar-widget');
    } else {
        $args = array(
            'before_widget' => '<div class="widget_block">',
            'after_widget' => '</div>',
            'before_title' => '<h6 class="widget_title">',
            'after_title' => '</h6>'
        );
        the_widget('WP_Widget_Search', null, $args);
        the_widget('WP_Widget_Archives', null, $args);
        the_widget('WP_Widget_Tag_Cloud', null, $args);
    } ?>
</aside>