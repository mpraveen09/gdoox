<?php

namespace Gdoox\Events;

abstract class Event
{
    //
}
