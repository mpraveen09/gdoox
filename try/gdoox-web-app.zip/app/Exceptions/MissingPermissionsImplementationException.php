<?php namespace Gdoox\Exceptions;

class MissingPermissionsImplementationException extends GdooxBaseException
{

}
