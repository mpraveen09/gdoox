<?php

namespace Gdoox\Http;

use Gdoox\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;

use Gdoox\Models\Categories;


class CommonFunctions1 extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
    }

    
}
