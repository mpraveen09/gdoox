<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;
//use Illuminate\Database\Eloquent\Model;

class AlertSystem extends Eloquent {
    protected $collection = 'alert_system';
}
