<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class AttributesAssoc extends Eloquent
{
    protected $collection = 'cat_attributes_assoc';
}
