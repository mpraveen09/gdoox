<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class AttributesType extends Eloquent
{
    protected $collection = 'cat_attributes_type';
}
