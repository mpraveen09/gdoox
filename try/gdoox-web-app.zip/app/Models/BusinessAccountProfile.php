<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class BusinessAccountProfile extends Eloquent
{
  protected $collection="business_account_profile";

}
