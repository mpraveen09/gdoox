<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class BusinessEcommerceCompany extends Eloquent
{
     protected $collection = 'business_ecommerce_companies';
    
}
