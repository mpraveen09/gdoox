<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class BusinessPartner extends Eloquent
{
  protected $collection="business_partners";
}
