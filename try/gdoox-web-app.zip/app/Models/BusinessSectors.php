<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class BusinessSectors extends Eloquent
{
  protected $collection="business_sectors";

}
