<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class BusinessVerificationLog extends Eloquent {
    protected $collection="business_verification_logs";
}
