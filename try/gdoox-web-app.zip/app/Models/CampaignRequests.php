<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CampaignRequests extends Eloquent {
     protected $collection = 'campaign_requests';
}
