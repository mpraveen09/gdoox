<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class Campaigns extends Eloquent {
     protected $collection = 'campaigns';
}
