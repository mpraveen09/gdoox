<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class CategoryUpload extends Eloquent
{
   protected $collection = 'cat_categories';  
  
}
