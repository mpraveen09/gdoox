<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CertificationLogos extends Eloquent
{
     protected $collection = 'certification_logos';
}
