<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;
//use Illuminate\Database\Eloquent\Model;

class CmsSite extends Eloquent
{
    protected $collection = 'cms_site';
    
}
