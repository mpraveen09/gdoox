<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class CompanyInvitation extends Eloquent
{
  protected $collection="business_company_invitations";
}
