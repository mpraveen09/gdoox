<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmAccounts extends Eloquent
{
     protected $collection = 'crm_accounts';
}
