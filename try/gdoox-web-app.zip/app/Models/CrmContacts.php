<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmContacts extends Eloquent
{
     protected $collection = 'crm_contacts';
}
