<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmContactsGroup extends Eloquent
{
     protected $collection = 'crm_contacts_groups';
}
