<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmCustomFieldMaster extends Eloquent
{
     protected $collection = 'crm_custom_field_master';
}
