<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmDropdownOptions extends Eloquent
{
     protected $collection = 'crm_dropdown_options';
}
