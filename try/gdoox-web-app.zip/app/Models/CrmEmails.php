<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmEmails extends Eloquent
{
     protected $collection = 'crm_emails';
}
