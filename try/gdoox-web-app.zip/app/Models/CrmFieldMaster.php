<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmFieldMaster extends Eloquent
{
     protected $collection = 'crm_field_master';
}
