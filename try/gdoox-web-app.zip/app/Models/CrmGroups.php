<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmGroups extends Eloquent
{
     protected $collection = 'crm_groups';
}
