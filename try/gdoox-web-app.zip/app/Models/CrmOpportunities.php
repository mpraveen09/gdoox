<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmOpportunities extends Eloquent
{
     protected $collection = 'crm_opportunities';
}
