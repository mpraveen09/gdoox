<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmTasks extends Eloquent
{
     protected $collection = 'crm_tasks';
}
