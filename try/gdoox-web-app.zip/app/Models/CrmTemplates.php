<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmTemplates extends Eloquent
{
     protected $collection = 'crm_templates';
}
