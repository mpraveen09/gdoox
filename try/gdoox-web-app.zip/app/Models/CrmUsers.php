<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class CrmUsers extends Eloquent
{
     protected $collection = 'crm_users';
}
