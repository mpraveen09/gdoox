<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class DistributionNetwork extends Eloquent
{
   protected $collection = 'distribution_network';  
}

