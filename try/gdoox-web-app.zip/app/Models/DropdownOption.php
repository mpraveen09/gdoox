<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class DropdownOption extends Eloquent
{
   protected $collection = 'dropdown_options_s';  
}
