<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class DropdownOptions extends Eloquent
{
    protected $collection = 'dropdown_options';
}
