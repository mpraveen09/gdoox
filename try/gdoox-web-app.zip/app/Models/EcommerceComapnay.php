<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;
//use Illuminate\Database\Eloquent\Model;

class EcommerceComapnay extends Eloquent
{
    protected $collection = 'ecommerce_companies'; 
}
