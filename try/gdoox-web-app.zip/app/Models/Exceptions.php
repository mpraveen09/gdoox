<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class Exceptions extends Eloquent
{
     protected $collection = 'exceptions';
}
