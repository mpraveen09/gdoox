<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class ExportProduct extends Eloquent
{
     protected $collection = 'products_export';
}
