<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class FieldMaster extends Eloquent
{
    //
     protected $collection = 'field_master';
}
