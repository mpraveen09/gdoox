<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class Follower extends Eloquent
{
     protected $collection = 'business_followers';
}
