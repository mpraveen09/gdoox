<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class ImportProduct extends Eloquent
{
     protected $collection = 'products_import';
}
