<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class InterestInfo extends Eloquent
{
     protected $collection = 'interest_info';
}
