<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;
// use Illuminate\Database\Eloquent\Model;

class NavigationMenu extends Eloquent
{
    protected $collection = 'nav_menus';
}
