<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class OrderTracking extends Eloquent
{
    protected $collection = 'order_tracking';
}
