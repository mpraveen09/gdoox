<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class PageHelp extends Eloquent
{
     protected $collection = 'page_help';
}
