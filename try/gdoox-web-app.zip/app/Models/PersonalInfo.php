<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class PersonalInfo extends Eloquent
{
     protected $collection = 'personal_info';
}
