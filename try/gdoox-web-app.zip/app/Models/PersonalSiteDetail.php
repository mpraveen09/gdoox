<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class PersonalSiteDetail extends Eloquent
{
     protected $collection = 'personal_site_details';
}
