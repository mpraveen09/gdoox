<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class PositionInComapany extends Eloquent
{
     protected $collection = 'per_position_in_company';
}
