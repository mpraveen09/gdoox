<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class ProductBiddings extends Eloquent {
     protected $collection = 'product_biddings';
}
