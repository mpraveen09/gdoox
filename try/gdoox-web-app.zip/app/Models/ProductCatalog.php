<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class ProductCatalog extends Eloquent
{
     protected $collection = 'product_catalog';
}
