<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class ProductHiddenAttributes extends Eloquent {
     protected $collection = 'product_hide_attributes';
}
