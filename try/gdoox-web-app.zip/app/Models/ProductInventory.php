<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class ProductInventory extends Eloquent {
     protected $collection = 'product_inventory';
}
