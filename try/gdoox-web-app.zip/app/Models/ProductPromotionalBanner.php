<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class ProductPromotionalBanner extends Eloquent
{
  protected $collection="product_promo_banners";
}
