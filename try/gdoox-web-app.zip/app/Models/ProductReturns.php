<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;
//use Illuminate\Database\Eloquent\Model;

class ProductReturns extends Eloquent
{
    protected $collection = 'product_returns';      
       
}
