<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class ProductReviews extends Eloquent
{
     protected $collection = 'product_reviews';
}
