<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;
//use Illuminate\Database\Eloquent\Model;

class ProductVariationAttributes extends Eloquent {
    protected $collection = 'product_variation_attributes';
}
