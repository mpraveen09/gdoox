<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;
//use Illuminate\Database\Eloquent\Model;

class ProductVariationFields extends Eloquent {
    protected $collection = 'product_variation_fields';
}
