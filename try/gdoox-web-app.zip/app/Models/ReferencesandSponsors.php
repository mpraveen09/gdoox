<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class ReferencesandSponsors extends Eloquent
{
     protected $collection = 'references_and_sponsors';
}
