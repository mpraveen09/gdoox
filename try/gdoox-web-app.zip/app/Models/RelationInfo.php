<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class RelationInfo extends Eloquent
{
     protected $collection = 'relation_info';
}
