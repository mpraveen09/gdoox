<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class SellerReviews extends Eloquent
{
     protected $collection = 'seller_reviews';
}
