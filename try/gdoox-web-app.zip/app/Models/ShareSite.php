<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class ShareSite extends Eloquent
{
     protected $collection = 'share_sites';
}
