<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class ShoppingAddressDetails extends Eloquent
{
     protected $collection = 'shopping_address_details';
}
