<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class ShoppingCart extends Eloquent
{
     protected $collection = 'shopping_cart';
}
