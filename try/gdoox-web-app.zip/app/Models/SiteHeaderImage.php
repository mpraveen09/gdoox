<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class SiteHeaderImage extends Eloquent
{
     protected $collection = 'site_header_images';
}
