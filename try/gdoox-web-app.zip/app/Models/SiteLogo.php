<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class SiteLogo extends Eloquent
{
     protected $collection = 'site_logo';
}
