<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class SocialInfo extends Eloquent
{
     protected $collection = 'social_info';
}
