<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class TeamMemberPermission extends Eloquent {
     protected $collection = 'team_member_permissions';
}