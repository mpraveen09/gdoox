<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class TeamMemberPermissionFields extends Eloquent {
     protected $collection = 'team_member_permission_fields';
}