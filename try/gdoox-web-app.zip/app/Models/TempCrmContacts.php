<?php

namespace Gdoox\Models;
use Jenssegers\Mongodb\Model as Eloquent;

class TempCrmContacts extends Eloquent
{
    protected $collection = 'temp_crm_contacts';
}
