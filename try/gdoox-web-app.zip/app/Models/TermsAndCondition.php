<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class TermsAndCondition extends Eloquent
{
     protected $collection = 'terms_and_conditions';
}
