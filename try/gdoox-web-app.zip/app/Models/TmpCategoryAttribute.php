<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class TmpCategoryAttribute extends Eloquent
{
   protected $collection = 'tmp_cat_attributes_relation';  
  
}
