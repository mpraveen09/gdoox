<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class TmpCategoryUpload extends Eloquent
{
   protected $collection = 'tmp_cat_categories';  
  
}
