<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

class UserPersonalInfo extends Eloquent
{
  protected $collection="user_personal_info";
}
