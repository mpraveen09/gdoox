<?php

namespace Gdoox\Models;

use Jenssegers\Mongodb\Model as Eloquent;

//use Illuminate\Database\Eloquent\Model;

class catalog_attributes extends Eloquent
{
    //protected $collection = 'catalog_attributes';
    protected $collection = 'test_';
}
