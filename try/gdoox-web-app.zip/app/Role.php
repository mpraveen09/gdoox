<?php

namespace Gdoox;

use Jenssegers\Mongodb\Model as Eloquent;

class Role extends Eloquent
{
    //
    protected $collection='roles';
    
}
