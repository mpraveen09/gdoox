<?php

namespace Gdoox;

use Jenssegers\Mongodb\Model as Eloquent;

class SubUser extends Eloquent
{
    protected $collection='sub_users';
    //
}
