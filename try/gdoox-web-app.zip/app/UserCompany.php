<?php

namespace Gdoox;

use Illuminate\Database\Eloquent\Model;

class UserCompany extends Model
{
    //
}
