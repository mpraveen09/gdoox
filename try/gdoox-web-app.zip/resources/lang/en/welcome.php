<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

return [
    'banner_title' => 'Hosted Business Eco-System Platform',
    'banner_subtitle1' => 'No Trading Fees',
    'banner_subtitle2' => 'It’s a PAY PER USE platform',
    'listitems' => "<li>More than 200 business sectors organizad by plants, machinery, equipment, accessories, product and services</li>
                <li>More than 23.000 product categories</li>
                <li>Create your offer using Gdoox: products ecosystem allows you to configure any product or service in the platform</li>
                <li>Cross product offer and demand</li>
                <li>Gdoox structure allows you to create your personalized e-commerce website</li>
                <li>Create your own e-commerce websites</li>
                <li>Create e-commerce sites with your partners</li>
                <li>Share products and services with your parners in a new e-commerce site</li>
                <li>Alliance Development</li>
                <li>Involve your company organization</li>"
];
