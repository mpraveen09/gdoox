@extends('layout.backend.master')
@extends('layout.backend.userinfo')

@section('right_col_title_left')
<h2>E-commerce Site</h2>
@endsection

@section('right_col_title_right')
@endsection

@section('header_add_js_script')        
@endsection

@section('right_col')

@if (Session::has('message'))
<div class="alert alert-info">{!!  Session::get('message')  !!}</div>
@endif

@if (HTML::ul($errors->all()))
    <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
        {!! HTML::ul($errors->all()) !!}
    </div>
@endif
     <div class="card">
        <div class="card-header bgm-blue">
          <h2>Add Logo</h2>
        </div><!-- .card-header -->
        <div class="card-body card-padding">  
          <div class="progress progress-striped active" style="display:none;">
                  <div class="progress-bar" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
                  </div>
          </div>
              <br/>
               <br/>
                {!! Form::open(['route'=>'site.logo.store', 'method'=>'POST', 'files' => true])!!}
                {!!Form::hidden('shop_id',$id)!!}
                <div class="row">
                    <div class="col-sm-12">
                        {!! Form::label('file','Browse Image',array("class"=>"control-label  col-md-3 col-sm-3 col-xs-12"))!!}
                        <div class="fileinput fileinput-new" data-provides="fileinput">
                            <span class="btn btn-primary btn-file m-r-10">
                                <span class="fileinput-new">Select file</span>
                                <span class="fileinput-exists">Change</span>
                                {!! Form::file('site_logo') !!}
                            </span>
                            <span class="fileinput-filename"></span>
                            <a href="#" class="close fileinput-exists" data-dismiss="fileinput">&times;</a>
                        </div>
                    </div>
                </div>
               <br>
                <div class="row">
                     <div class="form-group clearfix">
                       <div class="col-md-6 col-md-offset-3">
                           <button id="send" type="submit" class="btn btn-round btn-success process">Upload</button>
                           <button id="cancel_btn" onclick="goBack()" type="button" class="btn btn-round btn-primary">Cancel</button>
                       </div>
                     </div>
                </div>
               {!! Form::close() !!}
        </div>
    </div>
@if (!$esites->count())
            <div class="alert alert-warning alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"></span></button>
                There are no site logo
            </div>                 
    @else
        <div class="card">
            <div class="card-header bgm-blue">
                  <h2>Site Logo</h2>
            </div><!-- .card-header -->
            <div class="card-body card-padding">
                  <table class="table">
                        <thead>
                              <th>Site Logo</th>
                              <th>Action</th>
                        </thead>
                        
                        <tbody>
                             @foreach($esites as $esite)
                              <tr>
                                  <td>
                                      <div class="thumb">
                                        <a href="#" target="_blank"><img src='{!!asset("uploads/site_logo/$esite->site_logo")!!}' alt="Certification Logo" style="width:120px;"/></a>
                                      </div> 
                                  </td>
                                  <td><a href="{!!route('site.logo.edit',$esite->id)!!}"class=""><i class="zmdi zmdi-edit zmdi-hc-fw"></i></a>
                                  </td>
                              </tr>
                            @endforeach
                        </tbody>
                      </table>
                </div>
        </div>
    @endif

@endsection


@section('footer_add_js_files') 
        <script src="{{ asset('/m-admin-ui/vendors/fileinput/fileinput.min.js') }}"></script>
        <script src="{{ asset('/m-admin-ui/vendors/input-mask/input-mask.min.js') }}"></script>
@endsection       
@section('footer_add_js_script')
<script>
 $('.process').click(function(){
    $('.progress').css('display','block');
 });
 </script>
 
<script>
function goBack() {
    window.history.back();
}
</script>
@endsection
